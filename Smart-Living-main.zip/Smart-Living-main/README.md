# Smart-Living

Smart Living is an e commerce website which sells products and services which are related to smart homes.

Project is inside the master branch
